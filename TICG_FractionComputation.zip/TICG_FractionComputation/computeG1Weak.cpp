
#define _CRT_SECURE_NO_DEPRECATE
#include <iostream>
#include<cstdio>
#include <vector>
#include <math.h> 
using namespace std;

void save_file(char *path, float *data, int steps);
double G1(float zeta, float y);
void Compute_Miu_T_varation_TIOGCFraction(float zeta, float W, char *filepath);
void Compute_Miu_W_varation_TIOGCFraction(float zeta, float T, char *filepath);
////compute TIGC according to Eq.(41)
float compute_fraction_TIGC(float zeta, float miu_in, float W, float T);
float F0x(float x, float zeta);
float G0y(float y, float zeta);
float Gxy(float x, float y, float zeta);

int main()
{	
	 
	 float zeta = 4.0;//6.0;8.0
	
	 double W = 0.8;
	 char path1[256] = "../dataTchange_W0.8/sin_fraction_node_change_zeta4.txt";
	 Compute_Miu_T_varation_TIOGCFraction(zeta, W, path1);

	 W = 0.5;
	 char path2[256] = "../dataTchange_W0.5/sin_fraction_node_change_zeta4.txt";
	 Compute_Miu_T_varation_TIOGCFraction(zeta, W, path2);
}

double compute_miu(float zeta, float W, float T)
{
	double x, x_new, X, miu;
	x = 0.1;
	X = 1.0 - W * x;
	x_new = T * (1 - G1(zeta, X));
	while (fabs(x_new - x) > 1e-3)
	{
		x = x_new;
		X = 1.0 - W * x;
		x_new = T * (1 - G1(zeta, X));
	}
	miu = 1.0 - x;
	cout << miu << endl;
	return miu;
}
double G1(float zeta, float y)
{
	return  exp(zeta*(y - 1));
}
double F1(float zeta, int Nodes, float x)
{
	return exp(zeta*(x - 1));
}
void Compute_Miu_T_varation_TIOGCFraction(float zeta, float W, char *filepath)
{
	const int steps = 101;
	float T[steps] = { 0.0 };
	float miu[steps] = { 0.0 };
	float sin_fraction[steps] = { 0.0 };

	int i;
	for (i = 0; i < steps; i++)
	{
		T[i] = 1.0 / (steps - 1)*i;
		miu[i] = compute_miu(zeta, W, T[i]);
		sin_fraction[i] = compute_fraction_TIGC(zeta, miu[i], W, T[i]);
		cout << miu[i] << "  " << sin_fraction[i] << endl;
	}
	
	save_file(filepath, sin_fraction, steps);

}
void Compute_Miu_W_varation_TIOGCFraction(float zeta, float T, char *filepath)
{
	const int steps = 101;
	float W[steps] = { 0.0 };
	float miu[steps] = { 0.0 };
	float sin_fraction[steps] = { 0.0 };

	int i;
	for (i = 0; i < steps; i++)
	{
		W[i] = 1.0 / (steps - 1)*i;
		miu[i] = compute_miu(zeta, W[i], T);
		sin_fraction[i] = compute_fraction_TIGC(zeta,miu[i], W[i], T);
		cout << miu[i] << "  " << sin_fraction[i] << endl;
	}
	save_file(filepath, sin_fraction, steps);
}

float F0x(float x, float zeta)
{
	return exp(zeta*(x - 1));
}
float G0y(float y, float zeta)
{
	return exp(zeta*(y - 1));
}
float Gxy(float x, float y, float zeta)
{
	return exp(zeta * (x + y - 2.0));
}

float compute_fraction_TIGC(float zeta, float miu_in, float W, float T)
{
	float miu_i, sin_fraction;
	miu_i = 1 + (miu_in - 1)*W;
	sin_fraction = T * (1 - F0x(miu_i, zeta));
	return sin_fraction;
}

void save_file(char *path, float *data, int steps)
{
	FILE *fp;
	fp = fopen(path,"w");
	if (!fp) return;
	
	int i;
	char szBuffer[256];
	string str="";
	for (i = 0; i < steps; i++)
	{
		sprintf(szBuffer, "%f\n", data[i]);
		str += szBuffer;
	}
	fprintf(fp, str.c_str());
	fclose(fp);
}
